ln -s $PWD ~/.config/sublime-text-3/Packages/snippet-destroyer
