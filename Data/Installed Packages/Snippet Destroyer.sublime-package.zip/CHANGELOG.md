# sublime-snippet-destroyer changelog
1.0.2 - Replaced Gittip with support me page

1.0.1 - Repaired "empty" .tmSnippet not hiding snippets for Sublime Text 3

1.0.0 - Moved to override by default system. Fixes #3

0.2.2 - Fixed up lint errors

0.2.1 - Added foundry for release

0.2.0 - Added better support for overriding Default packages

0.1.1 - Added documentation on how to destroy snippets in Sublime Text 3

0.1.0 - Initial release
