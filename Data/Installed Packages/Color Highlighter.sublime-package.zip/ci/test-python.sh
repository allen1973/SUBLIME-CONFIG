#!/usr/bin/env bash

set -e

echo "Running $0..."

py.test
