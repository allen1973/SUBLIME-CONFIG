"""A dummy package for mocking ST API."""


class ApplicationCommand(object):  # pylint: disable=too-few-public-methods
    """Dummy ApplicationCommand."""

    pass


class TextCommand(object):  # pylint: disable=too-few-public-methods
    """Dummy TextCommand."""

    pass


class EventListener(object):  # pylint: disable=too-few-public-methods
    """Dummy EventListener."""

    pass
