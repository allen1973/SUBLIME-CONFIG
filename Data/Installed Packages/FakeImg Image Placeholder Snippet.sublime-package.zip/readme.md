# FakeImg Placeholder Snippet for Sublime Text 2 and 3

This is a clone of the SublimeText FakeImg.pl Plugin but it loads the images via HTTPS.

**tabTrigger** : `fakeimg`

This snippet tabs through all of the available options (and their `defaults`):

- horizontal size `350`
- vertical size `200`
- background color `00CED1` (darkturquoise)
- text color `FFF` (white)
- sample text `img+placeholder` (img placeholder)

FakeImg also has support for `&font=lobster` and possibly other fonts though options are not documented on the site.

Below is a screenshot of the default settings.

![Screenshot of the default image](https://bytebucket.org/fnkr/sublimefakeimg/raw/master/fakeimg-screenshot.png)